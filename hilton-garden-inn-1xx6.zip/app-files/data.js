var APP_DATA = {
  "scenes": [
    {
      "id": "0-img_20240727_085730_722",
      "name": "IMG_20240727_085730_722",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 0.819874695865888,
        "pitch": 0.35383758548109867,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.819874695865888,
          "pitch": 0.35383758548109867,
          "rotation": 0,
          "target": "1-img_20240727_090720_513"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-img_20240727_090720_513",
      "name": "IMG_20240727_090720_513",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 0.19967838206990685,
        "pitch": 0.29783002811964643,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -3.0305629461071977,
          "pitch": 0.2644407309377925,
          "rotation": 0,
          "target": "0-img_20240727_085730_722"
        },
        {
          "yaw": -1.333894053337632,
          "pitch": 0.27394006751942257,
          "rotation": 0,
          "target": "6-img_20240727_090056_136"
        },
        {
          "yaw": 1.6749465886764874,
          "pitch": 0.3775444812315829,
          "rotation": 0,
          "target": "8-img_20240727_085929_729"
        },
        {
          "yaw": 0.19967838206990685,
          "pitch": 0.29783002811964643,
          "rotation": 0,
          "target": "2-img_20240727_090638_348"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-img_20240727_090638_348",
      "name": "IMG_20240727_090638_348",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 0.5226677256697467,
        "pitch": 0.40019206298232746,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.528823534245948,
          "pitch": 0.5329895108807889,
          "rotation": 0,
          "target": "1-img_20240727_090720_513"
        },
        {
          "yaw": 0.6002585921001842,
          "pitch": 0.24732554831631148,
          "rotation": 0,
          "target": "3-img_20240727_090256_199"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-img_20240727_090256_199",
      "name": "IMG_20240727_090256_199",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "yaw": 0.3491454411615269,
        "pitch": 0.4887941832573297,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.669451132283868,
          "pitch": 0.48648649200246474,
          "rotation": 0,
          "target": "2-img_20240727_090638_348"
        },
        {
          "yaw": 0.4030476276797188,
          "pitch": 0.5220285070125357,
          "rotation": 0,
          "target": "4-img_20240727_090146_184"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-img_20240727_090146_184",
      "name": "IMG_20240727_090146_184",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 0.5245265194667308,
        "pitch": 0.33007469524464916,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.645504049926636,
          "pitch": 0.3453040044276001,
          "rotation": 0,
          "target": "3-img_20240727_090256_199"
        },
        {
          "yaw": 0.406242794461086,
          "pitch": 0.38132053285639955,
          "rotation": 0,
          "target": "5-img_20240727_090126_356"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "5-img_20240727_090126_356",
      "name": "IMG_20240727_090126_356",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": -0.020965789789245903,
        "pitch": 0.30092273173942274,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 3.0609456935197326,
          "pitch": 0.3844524028917995,
          "rotation": 0,
          "target": "4-img_20240727_090146_184"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "6-img_20240727_090056_136",
      "name": "IMG_20240727_090056_136",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": 1.7994747958587354,
        "pitch": 0.19206587952506204,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.2884657973232869,
          "pitch": 0.7132344677551892,
          "rotation": 0,
          "target": "7-img_20240727_090008_121"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "7-img_20240727_090008_121",
      "name": "IMG_20240727_090008_121",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2000,
      "initialViewParameters": {
        "yaw": -0.09502371651031893,
        "pitch": 0.9923253119781066,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.9861975432610395,
          "pitch": 0.5785982947679358,
          "rotation": 0,
          "target": "6-img_20240727_090056_136"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "8-img_20240727_085929_729",
      "name": "IMG_20240727_085929_729",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1488,
      "initialViewParameters": {
        "yaw": -0.8094987501251083,
        "pitch": 0.714786475598963,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.2779272493120306,
          "pitch": 0.6396467630263949,
          "rotation": 0,
          "target": "1-img_20240727_090720_513"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "Hilton Garden Inn 1xxx",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": false
  }
};
